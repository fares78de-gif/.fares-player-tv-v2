package com.fares.playertv

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Account(val server: String, val user: String, val pass: String)
data class Channel(val name: String, val url: String, val icon: String? = null)
data class Poster(val id: String, val title: String, val image: String?, val url: String?)

object Playlist {
    var items: List<Channel> = emptyList()
    var index = 0
    var live = true
}

fun View.scaleOnFocus() {
    setOnFocusChangeListener { v, f ->
        val s = if (f) 1.06f else 1f
        v.animate().scaleX(s).scaleY(s).setDuration(120).start()
    }
}

object Store {
    fun load(c: Context): MutableList<Account> {
        val s = c.getSharedPreferences("p", 0).getString("accounts", "[]")!!
        val a = JSONArray(s)
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Account(o.getString("s"), o.getString("u"), o.getString("p"))
        }
    }
    fun save(c: Context, l: List<Account>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("s", it.server).put("u", it.user).put("p", it.pass)) }
        c.getSharedPreferences("p", 0).edit().putString("accounts", a.toString()).apply()
    }
    fun active(c: Context): Account? {
        val l = load(c)
        if (l.isEmpty()) return null
        val i = c.getSharedPreferences("p", 0).getInt("active", 0)
        return l[i.coerceIn(0, l.size - 1)]
    }
    fun setActive(c: Context, i: Int) {
        c.getSharedPreferences("p", 0).edit().putInt("active", i).apply()
    }
}

object Xtream {
    fun normalize(s: String): String {
        var t = s.trim().trimEnd('/')
        if (!t.startsWith("http://") && !t.startsWith("https://")) t = "http://$t"
        return t
    }
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 45000
        c.setRequestProperty("User-Agent", "FaresPlayerTV/2.0")
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }
    private fun enc(s: String): String = Uri.encode(s)
    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.get(k).toString()
    private fun api(a: Account, action: String, extra: String = ""): String =
        "${a.server}/player_api.php?username=${enc(a.user)}&password=${enc(a.pass)}&action=$action$extra"
    private fun catParam(c: String?): String = if (c == null) "" else "&category_id=$c"

    private fun cats(a: Account, action: String): List<Pair<String, String>> {
        val j = JSONArray(get(api(a, action)))
        return List(j.length()) {
            val o = j.getJSONObject(it)
            str(o, "category_id") to str(o, "category_name")
        }
    }
    fun liveCategories(a: Account) = cats(a, "get_live_categories")
    fun vodCategories(a: Account) = cats(a, "get_vod_categories")
    fun seriesCategories(a: Account) = cats(a, "get_series_categories")

    fun live(a: Account, cat: String?): List<Channel> {
        val j = JSONArray(get(api(a, "get_live_streams", catParam(cat))))
        return List(j.length()) {
            val o = j.getJSONObject(it)
            Channel(
                str(o, "name"),
                "${a.server}/live/${enc(a.user)}/${enc(a.pass)}/${str(o, "stream_id")}.m3u8",
                str(o, "stream_icon").ifBlank { null }
            )
        }
    }
    fun movies(a: Account, cat: String?): List<Poster> {
        val j = JSONArray(get(api(a, "get_vod_streams", catParam(cat))))
        return List(j.length()) {
            val o = j.getJSONObject(it)
            val ext = str(o, "container_extension").ifBlank { "mp4" }
            val id = str(o, "stream_id")
            Poster(id, str(o, "name"), str(o, "stream_icon").ifBlank { null },
                "${a.server}/movie/${enc(a.user)}/${enc(a.pass)}/$id.$ext")
        }
    }
    fun seriesList(a: Account, cat: String?): List<Poster> {
        val j = JSONArray(get(api(a, "get_series", catParam(cat))))
        return List(j.length()) {
            val o = j.getJSONObject(it)
            Poster(str(o, "series_id"), str(o, "name"), str(o, "cover").ifBlank { null }, null)
        }
    }
    fun episodes(a: Account, seriesId: String): List<Channel> {
        val o = JSONObject(get(api(a, "get_series_info", "&series_id=$seriesId")))
        val eps = o.optJSONObject("episodes") ?: return emptyList()
        val out = mutableListOf<Channel>()
        val seasons = eps.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.toList()
        for (s in seasons) {
            val arr = eps.optJSONArray(s) ?: continue
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val ext = str(e, "container_extension").ifBlank { "mp4" }
                out.add(Channel(
                    "S$s E${str(e, "episode_num")}  ${str(e, "title")}",
                    "${a.server}/series/${enc(a.user)}/${enc(a.pass)}/${str(e, "id")}.$ext"
                ))
            }
        }
        return out
    }
}

class RowAdapter(
    var items: List<String>,
    val onClick: (Int) -> Unit,
    val onLong: ((Int) -> Unit)? = null
) : RecyclerView.Adapter<RowAdapter.VH>() {
    class VH(val t: TextView) : RecyclerView.ViewHolder(t)
    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_row, p, false) as TextView)
    override fun onBindViewHolder(h: VH, i: Int) {
        h.t.text = items[i]
        h.t.setOnClickListener { val x = h.bindingAdapterPosition; if (x >= 0) onClick(x) }
        h.t.setOnLongClickListener {
            val x = h.bindingAdapterPosition
            if (onLong != null && x >= 0) onLong.invoke(x)
            onLong != null
        }
    }
    override fun getItemCount() = items.size
}

class ChannelAdapter(
    var items: List<Channel>,
    val onClick: (Int) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.img)
        val name: TextView = v.findViewById(R.id.name)
    }
    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_channel, p, false))
    override fun onBindViewHolder(h: VH, i: Int) {
        val c = items[i]
        h.name.text = c.name
        if (c.icon.isNullOrBlank()) h.img.setImageDrawable(null) else h.img.load(c.icon)
        h.itemView.setOnClickListener { val x = h.bindingAdapterPosition; if (x >= 0) onClick(x) }
    }
    override fun getItemCount() = items.size
}

class PosterAdapter(
    var items: List<Poster>,
    val onClick: (Int) -> Unit
) : RecyclerView.Adapter<PosterAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.img)
        val name: TextView = v.findViewById(R.id.name)
    }
    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_poster, p, false))
    override fun onBindViewHolder(h: VH, i: Int) {
        val c = items[i]
        h.name.text = c.title
        if (c.image.isNullOrBlank()) h.img.setImageDrawable(null) else h.img.load(c.image)
        h.itemView.setOnClickListener { val x = h.bindingAdapterPosition; if (x >= 0) onClick(x) }
    }
    override fun getItemCount() = items.size
}
