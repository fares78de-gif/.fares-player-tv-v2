package com.fares.playertv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast

class HomeActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_home)
        bind(R.id.tileLive) { open(LiveActivity::class.java, null) }
        bind(R.id.tileMovies) { open(VodActivity::class.java, "movies") }
        bind(R.id.tileSeries) { open(VodActivity::class.java, "series") }
        bind(R.id.tileAccounts) { startActivity(Intent(this, MainActivity::class.java)) }
        bind(R.id.tileExit) { finish() }
    }

    override fun onResume() {
        super.onResume()
        val a = Store.active(this)
        findViewById<TextView>(R.id.tvAccount).text =
            if (a == null) "No account" else "${a.user} @ ${a.server}"
    }

    private fun bind(id: Int, action: () -> Unit) {
        val v = findViewById<View>(id)
        v.scaleOnFocus()
        v.setOnClickListener { action() }
    }

    private fun open(cls: Class<*>, mode: String?) {
        if (Store.active(this) == null) {
            Toast.makeText(this, "Add an account first", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            return
        }
        val i = Intent(this, cls)
        if (mode != null) i.putExtra("mode", mode)
        startActivity(i)
    }
}
