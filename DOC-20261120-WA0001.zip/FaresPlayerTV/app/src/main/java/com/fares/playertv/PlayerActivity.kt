package com.fares.playertv

import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private var pos = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        view = PlayerView(this).apply { useController = false }
        setContentView(view)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onStart() {
        super.onStart()
        player = ExoPlayer.Builder(this).build().also {
            view.player = it
            it.addListener(object : Player.Listener {
                override fun onPlayerError(e: PlaybackException) {
                    Toast.makeText(this@PlayerActivity, "Playback error: ${e.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            })
        }
        play(Playlist.index, pos)
    }

    private fun play(i: Int, start: Long = 0L) {
        val l = Playlist.items
        if (l.isEmpty()) return
        val n = (i + l.size) % l.size
        Playlist.index = n
        player?.apply {
            setMediaItem(MediaItem.fromUri(l[n].url))
            prepare()
            if (start > 0L) seekTo(start)
            playWhenReady = true
        }
        Toast.makeText(this, l[n].name, Toast.LENGTH_SHORT).show()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val k = e.keyCode
            val p = player
            if (Playlist.live) {
                if (k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_CHANNEL_UP) { pos = 0L; play(Playlist.index + 1); return true }
                if (k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_CHANNEL_DOWN) { pos = 0L; play(Playlist.index - 1); return true }
            } else if (p != null) {
                if (k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) { p.seekTo(p.currentPosition + 10000L); return true }
                if (k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_MEDIA_REWIND) { p.seekTo(maxOf(0L, p.currentPosition - 10000L)); return true }
            }
            if (p != null && (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)) {
                p.playWhenReady = !p.playWhenReady
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onStop() {
        super.onStop()
        pos = if (Playlist.live) 0L else (player?.currentPosition ?: 0L)
        player?.release()
        player = null
    }
}
