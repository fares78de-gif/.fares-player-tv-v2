package com.fares.playertv

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : Activity() {
    private lateinit var accounts: MutableList<Account>
    private lateinit var adapter: RowAdapter

    private fun labels() = accounts.map { "${it.user}  @  ${it.server}" }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        accounts = Store.load(this)
        adapter = RowAdapter(labels(), { i ->
            Store.setActive(this, i)
            Toast.makeText(this, "Account selected", Toast.LENGTH_SHORT).show()
            finish()
        }, { i ->
            accounts.removeAt(i)
            Store.save(this, accounts)
            Store.setActive(this, 0)
            adapter.items = labels()
            adapter.notifyDataSetChanged()
        })
        findViewById<RecyclerView>(R.id.rvAccounts).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
        findViewById<Button>(R.id.btnAdd).setOnClickListener {
            val s = findViewById<EditText>(R.id.etServer).text.toString()
            val u = findViewById<EditText>(R.id.etUser).text.toString().trim()
            val p = findViewById<EditText>(R.id.etPass).text.toString().trim()
            if (s.isBlank() || u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            accounts.add(Account(Xtream.normalize(s), u, p))
            Store.save(this, accounts)
            Store.setActive(this, accounts.size - 1)
            adapter.items = labels()
            adapter.notifyDataSetChanged()
            listOf(R.id.etServer, R.id.etUser, R.id.etPass).forEach { findViewById<EditText>(it).setText("") }
            Toast.makeText(this, "Account added and selected", Toast.LENGTH_SHORT).show()
        }
    }
}
