package com.fares.playertv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class LiveActivity : Activity() {
    private lateinit var acc: Account
    private var cats: List<Pair<String?, String>> = emptyList()
    private var chans: List<Channel> = emptyList()
    private lateinit var chAdapter: ChannelAdapter
    private lateinit var preview: PlayerView
    private lateinit var tvNow: TextView
    private var player: ExoPlayer? = null
    private var cur = -1

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        acc = Store.active(this) ?: run { finish(); return }
        setContentView(R.layout.activity_live)
        preview = findViewById(R.id.preview)
        preview.useController = false
        tvNow = findViewById(R.id.tvNow)

        chAdapter = ChannelAdapter(emptyList()) { i -> onChannel(i) }
        val rvCh = findViewById<RecyclerView>(R.id.rvChannels)
        rvCh.layoutManager = LinearLayoutManager(this)
        rvCh.adapter = chAdapter

        val catAdapter = RowAdapter(emptyList(), { i -> loadChannels(cats[i].first) })
        val rvCat = findViewById<RecyclerView>(R.id.rvCats)
        rvCat.layoutManager = LinearLayoutManager(this)
        rvCat.adapter = catAdapter

        Thread {
            try {
                val c = listOf<Pair<String?, String>>(null to "All channels") + Xtream.liveCategories(acc)
                runOnUiThread {
                    cats = c
                    catAdapter.items = c.map { it.second }
                    catAdapter.notifyDataSetChanged()
                }
            } catch (e: Exception) { toast("Login/server error: ${e.message}") }
        }.start()
    }

    private fun loadChannels(cat: String?) {
        Thread {
            try {
                val l = Xtream.live(acc, cat)
                runOnUiThread {
                    cur = -1
                    player?.stop()
                    chans = l
                    chAdapter.items = l
                    chAdapter.notifyDataSetChanged()
                }
            } catch (e: Exception) { toast("Error: ${e.message}") }
        }.start()
    }

    private fun onChannel(i: Int) {
        if (i == cur) {
            Playlist.items = chans
            Playlist.index = i
            Playlist.live = true
            startActivity(Intent(this, PlayerActivity::class.java))
        } else {
            cur = i
            playPreview()
        }
    }

    private fun playPreview() {
        if (cur < 0 || cur >= chans.size) return
        val c = chans[cur]
        player?.apply {
            setMediaItem(MediaItem.fromUri(c.url))
            prepare()
            playWhenReady = true
        }
        tvNow.text = c.name + "\nPress OK again for full screen"
    }

    override fun onStart() {
        super.onStart()
        player = ExoPlayer.Builder(this).build().also {
            preview.player = it
            it.addListener(object : Player.Listener {
                override fun onPlayerError(e: PlaybackException) {
                    toast("Playback error: ${e.errorCodeName}")
                }
            })
        }
        playPreview()
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }

    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }
}
