package com.fares.playertv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class VodActivity : Activity() {
    private lateinit var acc: Account
    private var mode = "movies"
    private var cats: List<Pair<String?, String>> = emptyList()
    private var posters: List<Poster> = emptyList()
    private var inEpisodes = false
    private lateinit var rv: RecyclerView
    private lateinit var tvTitle: TextView
    private lateinit var posterAdapter: PosterAdapter
    private lateinit var epAdapter: ChannelAdapter
    private var episodes: List<Channel> = emptyList()

    private fun heading() = if (mode == "movies") "Movies" else "Series"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        acc = Store.active(this) ?: run { finish(); return }
        mode = intent.getStringExtra("mode") ?: "movies"
        setContentView(R.layout.activity_vod)
        tvTitle = findViewById(R.id.tvTitle)
        tvTitle.text = heading()

        posterAdapter = PosterAdapter(emptyList()) { i ->
            val p = posters[i]
            if (mode == "movies") {
                play(listOf(Channel(p.title, p.url ?: "")), 0)
            } else {
                openSeries(p)
            }
        }
        epAdapter = ChannelAdapter(emptyList()) { i -> play(episodes, i) }

        rv = findViewById(R.id.rvGrid)
        showGrid()

        val catAdapter = RowAdapter(emptyList(), { i -> loadCategory(cats[i].first) })
        val rvCat = findViewById<RecyclerView>(R.id.rvCats)
        rvCat.layoutManager = LinearLayoutManager(this)
        rvCat.adapter = catAdapter

        Thread {
            try {
                val raw = if (mode == "movies") Xtream.vodCategories(acc) else Xtream.seriesCategories(acc)
                val c = listOf<Pair<String?, String>>(null to "All") + raw
                runOnUiThread {
                    cats = c
                    catAdapter.items = c.map { it.second }
                    catAdapter.notifyDataSetChanged()
                }
            } catch (e: Exception) { toast("Login/server error: ${e.message}") }
        }.start()
    }

    private fun showGrid() {
        inEpisodes = false
        rv.layoutManager = GridLayoutManager(this, 5)
        rv.adapter = posterAdapter
        tvTitle.text = heading()
    }

    private fun loadCategory(cat: String?) {
        if (inEpisodes) showGrid()
        Thread {
            try {
                val l = if (mode == "movies") Xtream.movies(acc, cat) else Xtream.seriesList(acc, cat)
                runOnUiThread {
                    posters = l
                    posterAdapter.items = l
                    posterAdapter.notifyDataSetChanged()
                }
            } catch (e: Exception) { toast("Error: ${e.message}") }
        }.start()
    }

    private fun openSeries(p: Poster) {
        Thread {
            try {
                val l = Xtream.episodes(acc, p.id)
                runOnUiThread {
                    episodes = l
                    epAdapter.items = l
                    epAdapter.notifyDataSetChanged()
                    rv.layoutManager = LinearLayoutManager(this)
                    rv.adapter = epAdapter
                    inEpisodes = true
                    tvTitle.text = p.title
                }
            } catch (e: Exception) { toast("Error: ${e.message}") }
        }.start()
    }

    private fun play(list: List<Channel>, index: Int) {
        Playlist.items = list
        Playlist.index = index
        Playlist.live = false
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    override fun onBackPressed() {
        if (inEpisodes) showGrid() else super.onBackPressed()
    }

    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }
}
